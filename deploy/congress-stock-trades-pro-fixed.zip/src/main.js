const { Actor } = require('apify');
const { gotScraping } = require('got-scraping');
const cheerio = require('cheerio');
const pdfParse = require('pdf-parse');

const BASE = 'https://disclosures-clerk.house.gov';
const SEARCH_URL = `${BASE}/FinancialDisclosure/ViewMemberSearchResult`;
const PDF_BASE = `${BASE}/public_disc/ptr-pdfs`;

const OWNER_RE = /^(SP|JT|DC|SC|SU|JU)\s+(.+)$/;
const TXN_RE = /^(P|S|E)\s*(\(partial\))?\s*(\d{1,2}\/\d{1,2}\/\d{4})\s*(\d{1,2}\/\d{1,2}\/\d{4})\s*\$([\d,]+)/;
const JUNK_RE = /(ID Owner Asset|Notification\s*Date|Cap\.\s*Gains|Clerk of the House|Filing ID #|Legislative Resource Center|Status\s*:\s*Member|State\/District|Hon\.|CERTIFY|STOCK Act|asset type abbreviations|Filer's Name|Transaction Type)/;
const TICKER_RE = /\(([A-Z][A-Z.]{0,5})\)\s*\[([A-Z]{1,3})\]/;
const DETAIL_RE = /^D[\s.:]*(.*)$/;
const STATUS_RE = /^F[\s.]*S[\s.:]*(.*)$/;

const AMOUNT_TABLE = {
    '1000': [1001, 15000], '15000': [15001, 50000], '50000': [50001, 100000],
    '100000': [100001, 250000], '250000': [250001, 500000],
    '500000': [500001, 1000000], '1000000': [1000001, 5000000], '5000000': [5000001, 25000000],
};

function cleanName(raw) {
    if (!raw) return { fullName: '', lastName: '', firstName: '' };
    let name = raw.replace(/\s+/g, ' ').trim();
    name = name.replace(/Hon\.\.*/g, 'Hon.').replace(/,\s*Hon\.?\s*/g, ', ').trim();
    const parts = name.split(',').map((p) => p.trim()).filter(Boolean);
    const last = parts[0] || '';
    const first = parts.slice(1).join(' ').replace(/Hon\.\s*/, '').trim();
    return { fullName: `${first} ${last}`.trim() || name, lastName: last, firstName: first };
}

function parseOffice(office) {
    if (!office) return { state: null, district: null };
    const m = String(office).trim().match(/^([A-Z]{2})(\d{0,2})$/);
    if (!m) return { state: String(office).trim(), district: null };
    return { state: m[1], district: m[2] || 'At-Large' };
}

function parseAmountRange(amountLine) {
    // "$1,000,001 - $5,000,000" or "$1,000,001 -" (continuation) or "$5,000,001"
    const nums = (amountLine.match(/\$?[\d,]{1,12}/g) || []).map((s) => Number(s.replace(/[$,\s]/g, '')));
    if (!nums.length) return null;
    let min = nums[0];
    let max = nums.length > 1 ? nums[nums.length - 1] : nums[0];
    if (min in AMOUNT_TABLE && nums.length === 1) [min, max] = AMOUNT_TABLE[min];
    const mid = (min + max) / 2;
    return { min, max, mid };
}

function parsePtrText(text) {
    const clean = String(text).replace(/\u0000/g, '');
    // Layout-agnostic: join non-junk lines into one string, then scan for transaction tokens.
    const flat = clean.split(/\r?\n/).map((l) => l.trim())
        .filter((l) => l && !JUNK_RE.test(l))
        .join(' ');

    const rows = [];
    const TXN_SPLICE = /(P|S|E)\s*(\(partial\))?\s*\d{1,2}\/\d{1,2}\/\d{2,4}\s*\d{1,2}\/\d{1,2}\/\d{2,4}\s*\$/;
    const TXN = /(P|S|E)\s*(\(partial\))?\s*(\d{1,2}\/\d{1,2}\/\d{2,4})\s*(\d{1,2}\/\d{1,2}\/\d{2,4})\s*\$([\d,]+)\s*(?:-\s*\$?([\d,]+))?/g;
    const TICK = /(?:\(([A-Z][A-Z.]{0,5})\)\s*)?\[([A-Z]{1,3})\]/g;
    const OWNER = /(SP|JT|DC|SC|SU|JU)(?=[A-Z])/g;

    const ticks = [];
    let m;
    while ((m = TICK.exec(flat)) !== null) {
        ticks.push({ idx: m.index, end: m.index + m[0].length, ticker: m[1] || null, code: m[2] });
    }
    const txns = [];
    while ((m = TXN.exec(flat)) !== null) {
        txns.push({
            idx: m.index, end: m.index + m[0].length,
            type: m[1], partial: !!m[2],
            tDate: m[3], nDate: m[4],
            lower: Number(m[5].replace(/,/g, '')),
            upperRaw: m[6] ? Number(m[6].replace(/,/g, '')) : null,
        });
    }

    const norm = (d) => {
        const p = d.split('/');
        const y = p[2].length === 2 ? `20${p[2]}` : p[2];
        return `${p[0]}/${p[1]}/${y}`;
    };

    const usedTick = new Set();
    for (const t of txns) {
        let best = null;
        let forward = false;
        for (const tk of ticks) {
            if (usedTick.has(tk.idx)) continue;
            if (tk.end <= t.idx && t.idx - tk.end <= 160) {
                const between = flat.slice(tk.end, t.idx);
                if (TXN_SPLICE.test(between)) continue;
                if (!best || tk.end > best.end) best = tk;
            }
        }
        if (!best) {
            for (const tk of ticks) {
                if (usedTick.has(tk.idx)) continue;
                if (tk.idx >= t.end && tk.idx - t.end <= 160) { best = tk; forward = true; break; }
            }
        }
        if (!best) continue;
        usedTick.add(best.idx);
        // owner code glued right before the asset name (backward from the ticker)
        const back = flat.slice(Math.max(0, best.idx - 160), best.idx);
        let owner = 'SP';
        let nameStart = 0;
        let om;
        OWNER.lastIndex = 0;
        while ((om = OWNER.exec(back)) !== null) { owner = om[1]; nameStart = om.index + om[0].length; }
        let asset = back.slice(nameStart).replace(/\s+/g, ' ').trim();
        asset = asset.slice(0, 60).replace(/^[^A-Z0-9]+/, '').trim();
        if (forward) {
            // ticker comes after the txn token: cut the txn tail off the asset name
            asset = asset.replace(/\s*(P|S|E)\s*(\(partial\))?\s*\d{1,2}\/\d{1,2}\/\d{2,4}.*$/, '').trim();
        }
        const assetLabel = best.ticker ? `${asset} (${best.ticker}) [${best.code}]` : `${asset} [${best.code}]`;

        let lower = t.lower;
        let upper = t.upperRaw;
        if (upper == null) {
            const after = flat.slice(best.end, best.end + 140);
            const um = after.match(/\$\s*([\d,]{4,12})/);
            if (um) {
                const v = Number(um[1].replace(/,/g, ''));
                if (v > lower) upper = v;
            }
        }
        if (upper == null) upper = lower;
        const mid = (lower + upper) / 2;

        rows.push({
            owner,
            asset: assetLabel,
            ticker: best.ticker,
            assetTypeCode: best.code,
            transactionType: t.type,
            partial: t.partial,
            transactionDate: norm(t.tDate),
            notificationDate: norm(t.nDate),
            amountMin: lower,
            amountMax: upper,
            amountMidpoint: mid,
            description: null,
            filingStatus: null,
        });
    }
    return rows;
}

function inDateRange(iso, start, end) {
    if (!iso || (!start && !end)) return true;
    const [m, d, y] = iso.split('/').map(Number);
    if (!y) return true;
    const t = new Date(Date.UTC(y < 100 ? 2000 + y : y, m - 1, d)).getTime();
    if (start && t < new Date(`${start}T00:00:00Z`).getTime()) return false;
    if (end && t > new Date(`${end}T23:59:59Z`).getTime()) return false;
    return true;
}

Actor.main(async () => {
    const input = await Actor.getInput();
    const year = Number(input.filingYear) || new Date().getUTCFullYear();
    const lastName = String(input.lastName || '').trim().toLowerCase();
    const maxItems = Math.min(Number(input.maxItems) || 1000, 5000);
    const includeDetails = input.includeDetails !== false;
    const start = input.startDate ? String(input.startDate).trim() : '';
    const end = input.endDate ? String(input.endDate).trim() : '';

    // 1) Filing index for the year (House Clerk member search returns every filing, incl. PTRs)
    let indexRes;
    for (let attempt = 1; attempt <= 3; attempt++) {
        try {
            indexRes = await gotScraping({
                url: SEARCH_URL,
                method: 'POST',
                headers: { 'content-type': 'application/x-www-form-urlencoded', referer: `${BASE}/FinancialDisclosure/ViewSearch` },
                body: `LastName=&FilingYear=${year}&State=`,
                timeout: { request: 60000 },
                responseType: 'text',
            });
            if (indexRes.statusCode === 200) break;
        } catch (e) { /* retry */ }
        await new Promise((r) => setTimeout(r, 2000 * attempt));
    }
    if (!indexRes || indexRes.statusCode !== 200) {
        await Actor.fail(`House Clerk filing index request failed (status ${indexRes ? indexRes.statusCode : 'none'})`);
        return;
    }

    const $ = cheerio.load(indexRes.body);
    const filings = [];
    $('tr').each((_, tr) => {
        const tds = $(tr).find('td');
        if (tds.length < 4) return;
        const linkEl = $(tds[0]).find('a');
        const href = linkEl.attr('href') || '';
        const pm = href.match(/ptr-pdfs\/(\d{4})\/(\d+)\.pdf/);
        if (!pm) return;
        const filingLabel = $(tds[3]).text().replace(/\s+/g, ' ').trim();
        if (!/PTR/i.test(filingLabel)) return;
        const { fullName, lastName: ln, firstName } = cleanName($(tds[0]).text());
        const office = $(tds[1]).text().replace(/\s+/g, ' ').trim();
        filings.push({
            docId: pm[2],
            filingYear: Number(pm[1]) || year,
            filingLabel,
            fullName, lastName: ln, firstName,
            ...parseOffice(office),
            pdfUrl: `${PDF_BASE}/${pm[1]}/${pm[2]}.pdf`,
        });
    });

    const wanted = lastName ? filings.filter((f) => f.lastName.toLowerCase().includes(lastName) || f.fullName.toLowerCase().includes(lastName)) : filings;

    let pushed = 0;
    let scanned = 0;
    for (const f of wanted) {
        if (pushed >= maxItems) break;
        scanned++;
        let text = null;
        try {
            const res = await gotScraping({ url: f.pdfUrl, timeout: { request: 60000 }, responseType: 'buffer' });
            if (res.statusCode === 200) text = (await pdfParse(res.body)).text;
        } catch (e) { /* unparsed filing: skip transactions, still transparent */ }
        if (!text) {
            await Actor.pushData({ ...f, transactionsFound: 0, parseError: 'PDF fetch or text extraction failed', source: 'US House Clerk (public_disc)' });
            pushed += 1;
            continue;
        }
        const rows = parsePtrText(text);
        for (const r of rows) {
            if (pushed >= maxItems) break;
            if (!inDateRange(r.transactionDate, start, end)) continue;
            await Actor.pushData({
                ...f,
                ...(includeDetails ? {} : { description: undefined, filingStatus: undefined }),
                transaction: r,
                source: 'US House Clerk (public_disc)',
            });
            pushed += 1;
        }
    }

    await Actor.pushData({
        _summary: true,
        filingYear: year,
        indexRows: filings.length,
        matchedFilings: wanted.length,
        pdfsScanned: scanned,
        transactionsPushed: pushed,
        note: 'Summary row. Individual transaction rows carry the filing member fields.',
    });
});
